# ssr 服务端渲染
# csr 客户端渲染

# MVVM dom diff
# weex